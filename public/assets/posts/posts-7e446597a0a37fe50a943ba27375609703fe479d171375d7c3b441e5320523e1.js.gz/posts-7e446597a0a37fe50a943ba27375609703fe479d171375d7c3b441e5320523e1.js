
var app = new Vue({

    element: "#posts-index",

    data: function() {
        return {

            message: "our first post"

        }
    }

})
;
